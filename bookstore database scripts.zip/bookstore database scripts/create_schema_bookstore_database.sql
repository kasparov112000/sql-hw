-- This script creates the database bookstore

CREATE DATABASE IF NOT EXISTS bookstore;

USE bookstore;
